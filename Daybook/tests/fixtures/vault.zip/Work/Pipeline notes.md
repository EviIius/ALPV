# Pipeline notes

See [[Other]].
